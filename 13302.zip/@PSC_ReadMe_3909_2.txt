Title: A String Calculator using Swing
Description: It simulates a calculator. This is a simple 4 function calculator that supports +, -, *, and /. This is a good example with a supporting tutorial on how to build it. Src included.
This file came from UNITAR BIT Student name wong chin fong.

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
Click on the batch file for execute.